

 <?php 
if (isset($_GET['order_id']) && $_GET['order_id'] == 'Order') {
 $cust_Id = Session::get("cust_Id");
 $insertOrder = $ct->orderProduct($cust_Id);
 $delData = $ct->delCustomerCart();
}
  ?>
<style>
body
{
	background-color: #BEBEBE;
	background-size: cover;
	background-position: center;
	font-family: sans serif;
}
.division{
	width: 50%;
	float: left;}
	
.tblone{
	width: 500px;
	margin: 0 auto;
	border: 2px solid #5E4752;
	margin-bottom: 10px;}
	
.tblone tr td{
	text-align: justify;
	}
.tbltwo{
	float: right;text-align: left;
	width: 60%;border: 2px solid #5E4752;
	margin-right: 14px;
	margin-top: 12px;
	}
.tbltwo tr td{
	text-align: justify;padding: 5px 10px;
	}
.ordernow{
	padding-bottom: 30px;
	}
.ordernow a{
	width:200px;
	margin: 20px auto 0;
	text-align: center;
	padding: 10px;
	font-size: 20px;
	display: block;
	background: #D8ACAD;
	color: #fff;
	border-radius: 3px;
	}
</style>

 <div class="main">
    <div class="content">
    	<div class="section group">
    	<div class="division">
         
            <table class="tblone">


                            <tr>
                                <th>No</th>
                                <th>MenuName</th>
								<th>Cafe</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                            <tr>

                            <?php 

                            $getPro = $ct->getCartProduct();
                            if ($getPro) {
                                $i = 0;
                                $sum = 0;
                                $qty = 0;
                                while ($result = $getPro->fetch_assoc()) {
                                
                                $i++;

                             ?>
                                <td><?php echo $i;?></td>
                                <td><?php echo $result['menu_name']; ?></td>
								<td><?php echo $result['cafe_id']; ?></td>
                                <td> <?php echo $result['price']; ?></td>
                                 <td><?php echo $result['quantity']; ?></td>
                                <td>
                             <?php
                        $total = $result['price'] * $result['quantity'];
                        echo $total;
                         ?>
                            

                                    </td>
                            </tr>
                            
                            <?php 
                            $qty = $qty + $result['quantity'];
                            $sum = $sum + $total;
                             ?>


                        <?php } } ?>    
                        </table> 
                        <table class="tbltwo">
                            <tr>
                                <td>Cod Charge</td>
                                <td>:</td>
                                <td>Rm 3 <?php echo $cod; ?></td>
                            </tr>
                            <tr>


                             <tr>
                                <td>Sub Total</td>
                                <td>:</td>
                                <td><?php echo $sum; ?></td>
                            </tr>
							<tr>
                                <td>Total</td>
                                <td>:</td>
                                <td><?php echo $sum + $cod; ?></td>
                            </tr>

                       </table>
                    
        </div>
        <div class="division">
            
            <?php 
            $cust_Id = Session::get("cust_id");
            $getdata = $cmr->getCustomerData($cust_Id);
            if ($getdata) {
                while ($result = $getdata->fetch_assoc()) {
            

             ?>
                <table class="tblone">
                    <tr>
                        <td colspan="3"><h2>Your Profile Details</h2></td>
                    </tr>
                    <tr>
                        <td width="20%">Name</td>
                        <td width="5%">:</td>
                        <td><?php echo $result['cust_name'];?></td>
                    </tr>
                    <tr>
                        <td>Tel No</td>
                        <td>:</td>
                        <td><?php echo $result['tel_no'];?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?php echo $result['email'];?></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>:</td>
                        <td><?php echo $result['address'];?></td>
                    </tr>
                    <tr>


                    <tr>
                        <td></td>
                        <td></td>
                        <td><a href="editprofile.php">Update Details</a></td>
                    </tr>

                </table>
            <?php }} ?>
        </div>
 		</div>
 	</div>

    <div class="ordernow"><a href="?orderid=Order">Place Order</a></div>
	</div>
