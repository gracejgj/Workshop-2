<!doctype html>
<?php
session_start();
require 'connection.php';
$conn = Connect();
?>
<html>
<head>
<meta charset="utf-8">
<title>Cart</title>
	
<link rel="stylesheet" href="menucart.css">
<link rel="stylesheet" type = "text/css" href ="bootstrap.min.css">
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="bootstrap.min.js"></script>
<style>
body {
	margin:0;
	background-color: #BEBEBE;
	}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.navbar-right {
  float: right;
}
  
.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px; /* Used in this example to enable scrolling */

}
</style>
</head>

<body>
	
<div class="navbar">
  <a><strong>Tapau's Delivery</strong></a>
  <a href="#news">Home</a>
  <div class="navbar-right">
  <a href="#news">Welcome </a>
  <a href="foodzone.php">Menu</a>
  <a href="menucart.php">Cart</a>
  <a href="orderdetails.php">Order History</a>
  <a href="editprofile.php">Profile</a>
  <a href="logout.php">Logout</a>
</div></div>

<?php
if(!empty($_SESSION["cart"]))
{
  ?>
  <div class="container">
      <div class="jumbotron">
        <h1>Cart</h1>
       
      </div>
      
    </div>
    <div class="table-responsive" style="padding-left: 100px; padding-right: 100px;" >
<table class="table table-striped">
  <thead class="thead-dark">
<tr>
<th width="40%">Food Name</th>
<th width="20%">Cafe</th>	
<th width="10%">Quantity</th>
<th width="20%">Price </th>
<th width="15%">Total </th>
<th width="5%">Action</th>
</tr>
</thead>


<?php  

$total = 0;
foreach($_SESSION["cart"] as $keys => $values)
{
?>
<tr>
<td><?php echo $values["menu_name"]; ?></td>
<td><?php echo $values["cafe_id"]; ?></td>
<td><?php echo $values["quantity"] ?></td>
<td>RM <?php echo $values["price"]; ?></td>
<td>RM <?php echo number_format($values["quantity"] * $values["price"], 2); ?></td>
<td><a href="menucart.php"cart.php?action=delete&id=<?php echo $values["menu_id"]; ?>"><span class="text-danger">Remove</span></a></td>
</tr>
<?php 
$total = $total + ($values["quantity"] * $values["price"]);
}
?>
<tr>
<td colspan="3" align="right">Total</td>
<td align="right">RM <?php echo number_format($total, 2); ?></td>
<td></td>
</tr>
</table>
<?php
  echo '<a href="cart.php?action=empty"><button class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Empty Cart</button></a>&nbsp;<a href="foodlist.php"><button class="btn btn-warning">Continue Shopping</button></a>&nbsp;<a href="payment.php"><button class="btn btn-success pull-right"><span class="glyphicon glyphicon-share-alt"></span> Check Out</button></a>';
?>
</div>
<br><br><br><br><br><br><br>
<?php
}
if(empty($_SESSION["cart"]))
{
  ?>
  <div class="container">
      <div class="jumbotron">
        <h1>Your Shopping Cart</h1>
        <p>Go back and <a href="foodlist.php">order now.</a></p>
        
      </div>
      
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <?php
}
?>


<?php


if(isset($_POST["add"]))
{
if(isset($_SESSION["cart"]))
{
$item_array_id = array_column($_SESSION["cart"], "menu_id");
if(!in_array($_GET["cust_id"], $item_array_id))
{
$count = count($_SESSION["cart"]);

$item_array = array(
'menu_id' => $_GET["menu_id"],
'cafe_id' => $_GET["cafe_id"]
'menu_name' => $_POST["hidden_name"],
'price' => $_POST["hidden_price"],
'quantity' => $_POST["quantity"]
);
$_SESSION["cart"][$count] = $item_array;
echo '<script>window.location="foodzone.php"</script>';
}
else
{
echo '<script>alert("Products already added to cart")</script>';
echo '<script>window.location="menucart.php"</script>';
}
}
else
{
$item_array = array(
'menu_id' => $_GET["cust_id"],
'cafe_id' => $_GET["cafe_id"],
'menu_name' => $_POST["hidden_name"],
'price' => $_POST["hidden_price"],
'food_quantity' => $_POST["quantity"]
);
$_SESSION["cart"][0] = $item_array;
}
}
if(isset($_GET["action"]))
{
if($_GET["action"] == "delete")
{
foreach($_SESSION["cart"] as $keys => $values)
{
if($values["menu_id"] == $_GET["cust_id"])
{
unset($_SESSION["cart"][$keys]);
echo '<script>alert("Food has been removed")</script>';
echo '<script>window.location="menucart.php"</script>';
}
}
}
}

if(isset($_GET["action"]))
{
if($_GET["action"] == "empty")
{
foreach($_SESSION["cart"] as $keys => $values)
{

unset($_SESSION["cart"]);
echo '<script>alert("Cart is made empty!")</script>';
echo '<script>window.location="cart.php"</script>';

}
}
}


?>
<?php

?>

    </body>


</html>