<!doctype html>
<?php
session_start();
require 'connection.php';
$conn = Connect();
?>
<html>
<head>
<meta charset="utf-8">
<title>payment</title>
	
<link rel="stylesheet" href="payment.css">
<link rel="stylesheet" type = "text/css" href ="bootstrap.min.css">
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="bootstrap.min.js"></script>
<style>
body {
	margin:0;
	background-color: #BEBEBE;
	}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.navbar-right {
  float: right;
}
  
.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px; /* Used in this example to enable scrolling */

}
</style>
</head>

<body>
	
<div class="navbar">
  <a><strong>Tapau's Delivery</strong></a>
  <a href="#news">Home</a>
  <div class="navbar-right">
  <a href="#news">Welcome </a>
  <a href="foodzone.php">Menu</a>
  <a href="menucart.php">Cart</a>
  <a href="orderdetails.php">Order History</a>
  <a href="editprofile.php">Profile</a>
  <a href="logout.php">Logout</a>
</div></div>




        </div>

      </div>
    </nav>



<?php
$gtotal = 0;
  foreach($_SESSION["cart"] as $keys => $values)
  {

    $menu_id = $values["menu_id"];
    $menu_name = $values["menu_name"];
    $quantity = $values["quantity"];
    $price =  $values["price"];
    $total = ($values["quantity"] * $values["price"]);
    $cafe_id = $values["cafe_id"];
    $cust_id = $_SESSION["login_user2"];
    $order_date = date('Y-m-d');
    
    $gtotal = $gtotal + $total;


     $query = "INSERT INTO ORDERS (menu_ID, menu_name, price,  quantity, order_date, cust_id, cafe_id) 
              VALUES ('" . $menu_id . "','" . $menu_name . "','" . $price . "','" . $quantity . "','" . $order_date . "','" . $cust_id . "','" . $cafe_id . "')";
             

              $success = $conn->query($query);         


      
  }

        ?>
        <div class="container">
         
        </div>
        <br>
<h1 class="text-center">Choose payment option</h1>
<br>
<h1 class="text-center">
  <a href="menucart.php"><button class="btn btn-warning"> Go back to cart</button></a>
  <a href="invoice.php"><button class="btn btn-success">Cash On Delivery</button></a>
  <a href="#news"><button class="btn btn-success">online payment</button></a>
</h1>

        


<br><br><br><br><br><br>
        </body>

  
</html>