<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User profile</title>
<link rel="stylesheet" href="editprofile.css">
<style>
body {margin:0;}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.navbar-right {
  float: right;
}
  
.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px; /* Used in this example to enable scrolling */

}
</style>

</head>
<?php 
include 'food_list.php';
$login = Session::get("cuslogin");
if ($login == false) {
    header("Location:login.php");
}
 ?>

<?php
$cust_id = Session::get("cust_id");
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $updateCust = $cust->customerUpdate($_POST,$cust_id);
}

?>
<body>

<div class="navbar">
  <a><strong>Tapau's Delivery</strong></a>
  <a href="#news">Home</a>
  <div class="navbar-right">
  <a href="#news">Welcome </a>
  <a href="foodzone.php">Menu</a>
  <a href="menucart.php">Cart</a>
  <a href="orderdetails.php">Order History</a>
  <a href="editprofile.php">Profile</a>
  <a href="logout.php">Logout</a>
</div></div>
 

	
 <div class="main">
    <div class="content">
    	<div class="section group">
    		<?php 
    		$cust_id = Session::get("cust_id");
    		$getdata = $cmr->getCustomerData($cust_id);
    		if ($getdata) {
    			while ($result = $getdata->fetch_assoc()) {
    		

    		 ?>
    		 <form action="" method="post">
				<table class="tblone">
					<?php 
					if (isset($updateCust)) {
					
					echo "<tr><td colspan='2'>".$updateCust."</td></tr>";
					}
					 ?>
					<tr>
						<td colspan="2"><h2>Update Profile Details</h2></td>
					</tr>
					<tr>
						<td width="20%">Name</td>
						<td><input type="text" name="cust_name" value="<?php echo $result['cust_name'];?>"></td>
						
					</tr>
					<tr>
						<td>Email</td>
						<td><input type="text" name="email" value="<?php echo $result['email'];?>"></td>
					</tr>
					<tr>
						<td>Tel No</td>
						<td><input type="text" name="tel_no" value="<?php echo $result['tel_no'];?>"></td>
						
					</tr>

					<tr>
						<td>Address</td>
						<td><input type="text" name="address" value="<?php echo $result['address'];?>"></td>
					</tr>


				  <tr>
						<td></td>
						<td><input type="submit" name="submit" value="Save"></td>
					</tr>

				</table>
				</form>
			<?php }} ?>
 		</div>

</body>
</html>
