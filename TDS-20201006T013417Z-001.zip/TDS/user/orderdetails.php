<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User profile</title>
<link rel="stylesheet" href="orderdetails.css">
<link rel="stylesheet" type = "text/css" href ="bootstrap.min.css">
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="bootstrap.min.js"></script>
<style>
body {
	margin:0;
	background-color: #BEBEBE;
	}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.navbar-right {
  float: right;
}
  
.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px; /* Used in this example to enable scrolling */

}
</style>

</head>
<?php 
include 'food_list.php';
if (isset($_GET['customerId'])) {
    $id = $_GET['customerId'];
    $confirm = $ct->productShiftConfirm($id);

}

 ?>
	<body>

<div class="navbar">
  <a><strong>Tapau's Delivery</strong></a>
  <a href="#news">Home</a>
  <div class="navbar-right">
  <a href="#news">Welcome </a>
  <a href="foodzone.php">Menu</a>
  <a href="menucart.php">Cart</a>
  <a href="orderdetails.php">Order History</a>
  <a href="editprofile.php">Profile</a>
  <a href="logout.php">Logout</a>
</div></div>
		
 <style>
     .tblone tr td{text-align: justify;}

 </style>
 <div class="main">
    <div class="content">
    	<div class="section group">
    		<div class="order">
    			<h2>Your Ordered Details</h2>
                <table class="tblone">


                            <tr>
                                <th>No</th>
                                <th>Product Name</th>
								<th>Cafe</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <tr>

                            <?php 
                            $cust_Id = Session::get("cust_Id");
                            $getOrder = $ct->getOrderedProduct($cust_Id);
                            if ($getOrder) {
                                $i = 0;
                                while ($result = $getOrder->fetch_assoc()) {
                                
                                $i++;

                             ?>
                                <td><?php echo $i;?></td>
                                <td><?php echo $result['menu_Name']; ?></td>
								<td><?php echo $result['cafe_id']; ?></td>
                                <td><?php echo $result['quantity']; ?></td>
                                <td>Rm <?php echo $result['price'];?></td>
                         <td><?php echo $fm->formatDate($result['order_date']); ?></td>

                         <td><?php

                         if ($result['status'] == '0') {
                             echo "Pending";
                         }elseif($result['status'] == '1'){
                            echo "Deliver";
                       } else{ 
                            echo "Ok";
                         }


           ?></td>
                    </td>

                
                    <?php 
                    if ($result['status'] == '1') { ?>
                     <td> <a href="?cust_id=<?php echo $result['cust_id']; ?>">Confirm</a><td>
                   <?php } elseif($result['status'] == '2'){?>
                    <td>Ok</td>

                  <?php }elseif ($result['status'] == '0') {?>
                      <td>N/A</td>
                 <?php  }  ?>
                   
            </tr>
                            


                        <?php } } ?>    
                        </table>

    		</div>
    	</div>
    	
    	 	
       <div class="clear"></div>
    </div>
 </div>
	</body>
</html>