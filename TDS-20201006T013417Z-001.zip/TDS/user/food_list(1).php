<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {margin:0;}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.navbar-right {
  float: right;
}
  
.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px; /* Used in this example to enable scrolling */

}
</style>
</head>

<body>

<div class="navbar">
  <a><strong>Tapau's Delivery</strong></a>
  <a href="#news">Home</a>
  <div class="navbar-right">
  <a href="#news">Welcome </a>
  <a href="#news">Food zone</a>
  <a href="#news">Cart</a>
  <a href="#news">Order History</a>
  <a href="#news">User Profile</a>
  <a href="logout.php">Logout</a>
</div></div>

</body>
</html>
