<?php
session_start();
include_once("inc/config.php");

	$mc = ($_POST['mc_id']);
	$cafe = ($_POST['cafe_id']);
	$code = ($_POST['menu_code']);
	$name = ($_POST['menu_name']);
	$fees = ($_POST['price']);
       
$sql = "INSERT INTO menu (mc_id, cafe_id, menu_code, menu_name, price) VALUES ('$mc', '$cafe', '$code', '$name', '$fees')";

if (mysqli_query($mysqli,$sql)){
	echo '<script type="text/javascript">alert("New menu added!");</script>';
	header("Location:http://localhost/TDS/staff/C2/product.php");
} 
else 
{
	echo '<script type="text/javascript">alert("Error Occured");</script>';
	header("Location:http://localhost/TDS/staff/C2/menu_add.php");

}



?>