<!DOCTYPE html>
<html>

<script type="text/javascript">
	function checkoutFunction(){	
		
		alert("New Menu Added!");
		window.location.assign("foods.php");

	}
</script>
<body>
	<div id="wrapper">
	<?php include 'inc/header.php';?>
	<div id="content">
	<br><br><br><br>
	<h2 style="text-align:center">NEW MENU</h2>
	<br><br>
	<form name="form" method="post" action="menu_add2.php" align="center"> 
	
		<input type="hidden" name="new" value="1" />
		
		<p><input type="text" name="menu_code" placeholder="Code" required /></p>
		<br>
		<p><input type="text" name="menu_name" placeholder="Name" required /></p>
		<br>
		<p><input type="text" name="mc_id" placeholder="Category Id" required /></p>
		<br>
		<p><input type="text" name="cafe_id" placeholder="Cafe ID is 3" required /></p>
		<br>
		<p><input type="number" name="price" placeholder="Price" required /></p>
		<br>
		
		<!--<p><form onsubmit="submitForm(event);">
		<input type="file" name="image" id="image-selecter" accept="image/*">
		<input type="submit" name="submit" value="Upload Image"></form></p>-->
		<br>

	<p style="flex-direction:column">
	 <input type="reset" class="button button4" value="RESET" />
	<input type="submit" onclick="checkoutFunction();" class="button button4" value="SUBMIT" />
	</p></br>

	</form>
	
	<br />
	</div>

	<div id="footer">Copyright <a href="cs2.php">Tapau's Delivery System</a>. All Rights Reserved.</div>
	 <script type="text/JavaScript">
//Script courtesy of BoogieJack.com
var message="NoRightClicking";
function defeatIE() {if (document.all) {(message);return false;}}
function defeatNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=defeatNS;}
else{document.onmouseup=defeatNS;document.oncontextmenu=defeatIE;}
document.oncontextmenu=new Function("return false")
</script>
	</div>
	</body>
	</html>