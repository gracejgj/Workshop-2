<!DOCTYPE html>

<?php
	include 'session.php';
	
	$p_id = $_GET['pid'];
	$sql = "select * from menu where menu_id = '$p_id'";
	$result = mysqli_query($connect,$sql);
	$rows = mysqli_fetch_array($result);
?>

<html>
<head>
<title>Employee | Tapau's Delivery System</title>
<link rel="stylesheet" type="text/css" href="css/styles.css" />
<script src="canvasjs.min.js"></script>
</head>

<body>
<div id="wrapper">
  <div id="header">
	
		<div class="logout">
		Welcome,  <?php echo $_SESSION['emp_name'];?> 
		<a href='logout.php'>Logout</a>
		</div>	
  </div>
 
   <div id="navigation">
	    <!--<ul>
		<li><a href="cs1.php"><span>MY CAFE</span></a></li>
		<li><a href="order.php"><span>ORDERS</span></a></li>
		<li><a href="delivery.php"><span>DELIVERY</span></a></li>
		<li><a href="product.php"><span>PRODUCTS</span></a></li>
		<li><a href="app.php"><span>APPLICATION</span></a></li>	
		 </ul>-->
		<div style="float:right">
		<?php
		echo date('d/m/Y  H:i:s');
		?>
		</div>
  </div>
 
<div id="content">
<br><br><br>

<form action="beverages_update2.php?pid=<?php echo $p_id; ?>" method="post">
    <table border="0" width="40%" align="center">
	<tr><td><h3>Update Beverage Menu</h3></td></tr>
	
	<!--<tr><td>Menu Code</td>
	<td><input type="text" name="menu_name" value="<php echo $rows['menu_code']; ?>" required />
	</td></tr>-->
	
	<tr><td>Menu Name</td>
	<td><input type="text" name="menu_name" value="<?php echo $rows['menu_name']; ?>" />
	</td></tr>
	
	<tr><td>Price</td>
	<td><input type="text" name="price" value="<?php echo $rows['price']; ?>" />
	</td></tr>

	  <tr>
            <td colspan="2" align="center">
                <input type="submit" value="Confirm" name="submit" />
                <input type="reset" value="Clear" name="reset" />
            </td>
        </tr>
</table>
</form>

</div>

<div id="footer">Copyright <a href="dashboard.php">Tapau's Delivery System</a>. All Rights Reserved. </div>
</div>
</body>
</html>						