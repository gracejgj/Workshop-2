<?php

include 'session.php';

if(isset($_POST['submit']))
{
	$p_id = $_GET['pid'];
	$pname = $_POST['menu_name'];
	$price = $_POST['price'];
	
	$sql = "update menu set menu_name = '$pname' , price = '$price' where menu_id = '$p_id'";
	$result = mysqli_query($connect,$sql);
	
	if($result)
	{
		?>
		<script>
			alert("Menu has been updated.");
			window.location.href = "foods.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert("Fail to update.");
			window.location.href = "foods_update.php?pid=<?php echo $p_id; ?>";
		</script>
		<?php
	}
}
?>