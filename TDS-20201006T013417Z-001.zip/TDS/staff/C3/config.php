<?php
	$connect = mysqli_connect("localhost", "root", "", "tapau_delivery");
?>